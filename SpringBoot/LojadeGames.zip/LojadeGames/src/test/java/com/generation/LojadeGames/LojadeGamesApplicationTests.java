package com.generation.LojadeGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojadeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
