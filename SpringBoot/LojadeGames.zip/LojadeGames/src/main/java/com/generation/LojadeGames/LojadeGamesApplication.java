package com.generation.LojadeGames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojadeGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojadeGamesApplication.class, args);
	}

}
